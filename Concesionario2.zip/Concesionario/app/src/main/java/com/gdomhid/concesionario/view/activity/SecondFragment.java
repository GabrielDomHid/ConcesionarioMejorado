package com.gdomhid.concesionario.view.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.denzcoskun.imageslider.models.SlideModel;
import com.gdomhid.concesionario.databinding.FragmentSecondBinding;
import com.gdomhid.concesionario.model.entity.Coche;
import com.denzcoskun.imageslider.constants.ScaleTypes;

import java.util.ArrayList;
import java.util.List;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    public Coche coche;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initialize();
        getActivity().setTitle(coche.getTitulo());
    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    /**
     * Recupero el coche que me lo envio del primer fragmento y le asigno a cada campo la informacion
     */
    private void initialize() {
        Bundle bundle;
        bundle = getArguments();
        coche = bundle.getParcelable("coche");
        if (String.valueOf(coche.getAño()) == null){
            binding.tvAnoo.setText("Not defined");}else{binding.tvAnoo.setText(String.valueOf(coche.getAño()));}
        if (coche.getCambio() == null){
            binding.tvCambioMarchas.setText("Not defined");}else{binding.tvCambioMarchas.setText(coche.getCambio());}
        if (coche.getColor() == null){
            binding.tvColoor.setText("Not defined");}else{binding.tvColoor.setText(coche.getColor());}
        binding.tvCombu.setText(coche.getCombustible());
        binding.tvkm.setText(String.valueOf(coche.getKm()));
        binding.tvDescripcion.setText(coche.getDescripcion());
        binding.tvPre.setText(coche.getPrecio());
        binding.tvponteciacv.setText(String.valueOf(coche.getCv()));
        binding.tvPuertasN.setText(String.valueOf(coche.getPuertas()));
        binding.tvRef.setText(String.valueOf(coche.getReferencia()));
        binding.tvUbi.setText(coche.getUbicacion());
        //Glide.with(getContext()).load(coche.getImagenes()).into(binding.ivCochee);
        //Si le doy a comprar me muestra un toast
        binding.bComprar.setOnClickListener(view -> {
            Toast.makeText(getContext(),"Te llamaran para comprar el coche.",Toast.LENGTH_LONG).show();
        });
        List<SlideModel> slider = new ArrayList<>();
        //Saco la lista de links de la base de datos
        String[] listaCoches = coche.getImagenes().split(",");
        slider.add(new SlideModel(listaCoches[0],"",ScaleTypes.CENTER_CROP));//añado el primero
        int c = 10;
        if (listaCoches.length < 10){c = listaCoches.length;}
        for (int i = 1; i < c ; i++) {
            slider.add(new SlideModel(listaCoches[i]+"?rule=detail_640x480_jpeg","",ScaleTypes.CENTER_CROP));//añado el resto
        }
        binding.imageSlider.setImageList(slider);//le pongo al slider la lista que tengo
    }
}