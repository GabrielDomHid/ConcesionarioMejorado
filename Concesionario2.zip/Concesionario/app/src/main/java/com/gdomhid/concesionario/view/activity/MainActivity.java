package com.gdomhid.concesionario.view.activity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;

import com.gdomhid.concesionario.R;
import com.gdomhid.concesionario.model.entity.Coche;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;


import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.gdomhid.concesionario.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    public static ArrayList<Coche> coches = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        new InfoAsyncTask().execute();//Ejecuta la consulta a base de datos
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            //Cuando hago clic en contacto en el menu navego al tercer fragmento
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
            navController.navigateUp();
            navController.navigate(R.id.thirdFragment);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
    @SuppressLint("StaticFieldLeak")
    public class InfoAsyncTask extends AsyncTask<Void, Void, ArrayList<Coche>> {
        @Override
        protected ArrayList<Coche> doInBackground(Void... voids) {
            ArrayList<Coche> infoCoche = new ArrayList<>();
            Connection connection;
            try {
                //Me conecto a la base de datos
                connection = DriverManager.getConnection("jdbc:mariadb://146.59.237.189:3306/dam208_gdhconcesionario","dam208_gdh","dam208_gdh");
                String sql = "SELECT * FROM coches";//La consulta
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();//Obtengo el resultado
                resultSet.first(); //Me posiciono al principio
                Coche coche;
                coche = creaCoche(resultSet);//creo un coche con el método personalizado
                coches.add(coche);//Lo añado a la lista
                while (resultSet.next()) {//Sigo creando coches mientras hayas datos en la base de datos
                    coche = creaCoche(resultSet);
                    coches.add(coche);
                    infoCoche.add(coche);
                }
                Log.v("xyzyz", "Array de coches completo: " + coches.toString());
                return infoCoche;
            } catch (Exception e) {
                Log.e("InfoAsyncTask", "Error reading school information", e);
            }
            return infoCoche;
        }
    }

    /**
     *  Con los datos de la consulta creo un coche con todos sus campos
     * @param resultSet Resultado de la consulta
     * @return un coche
     */
    public Coche creaCoche(ResultSet resultSet){
        int id = 0,referencia = 0,km = 0,cv = 0,puertas = 0,año = 0;
        String titulo = "",precio = "",descripcion = "",ubicacion = "",combustible = "",cambio = ""
                ,color = "",imagenes = "";
        try {
            id = resultSet.getInt("Id");
            referencia = resultSet.getInt("Referencia");
            titulo = resultSet.getString("Titulo");
            precio = resultSet.getString("Precio");
            descripcion = resultSet.getString("Descripcion");
            ubicacion = resultSet.getString("Ubicacion");
            imagenes = resultSet.getString("Imagenes");
            combustible = resultSet.getString("Combustible");
            km = resultSet.getInt("km");
            cambio = resultSet.getString("Cambio");
            cv = resultSet.getInt("Potencia");
            puertas = resultSet.getInt("NPuertas");
            color = resultSet.getString("Color");
            año = resultSet.getInt("Ano");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        Coche coche = new Coche(id,referencia,km,cv,puertas,año,titulo,precio,descripcion,ubicacion,
                combustible,cambio,color,imagenes);
        return coche;
    }
}